import boto3
import pandas as pd
import io
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')
s3 = boto3.client('s3')

def lambda_handler(event, context):
    try:
        # Get the bucket and object key from the event
        bucket_name = event['Records'][0]['s3']['bucket']['name']
        file_key = event['Records'][0]['s3']['object']['key']
        
        logger.info(f"Received event. Bucket: {bucket_name}, Key: {file_key}")
        
        # Get the object from S3
        response = s3.get_object(Bucket=bucket_name, Key=file_key)
        file_content = response['Body'].read()
        
        # Log successful retrieval
        logger.info(f"Successfully retrieved file {file_key} from bucket {bucket_name}")
        
        # Read the Excel file
        df = pd.read_excel(io.BytesIO(file_content))
        
        # Log the dataframe shape
        logger.info(f"Read Excel file with shape {df.shape}")
        
        # Convert DataFrame to CSV
        csv_buffer = io.StringIO()
        df.to_csv(csv_buffer, index=False)
        csv_key = file_key.replace('.xlsx', '.csv')
        
        # Upload CSV to S3
        s3.put_object(Bucket=bucket_name, Key=csv_key, Body=csv_buffer.getvalue())
        logger.info(f"Successfully uploaded CSV to {csv_key}")
        
        # Process the data and insert into DynamoDB
        table = dynamodb.Table('ProjectData')
        for index, row in df.iterrows():
            item = {
                'ProjectID': str(row['Project ID']),
                'Timestamp': str(row['Timestamp']),
                'DailySpendUSD': row['Daily Spend (GBP)'],
                'ManHoursWorked': row['Man-Hours Worked'],
                'ProgressPercent': row['Progress (%)'],
            }
            table.put_item(Item=item)
            logger.info(f"Inserted item into DynamoDB: {item}")
        
        logger.info("Data processed and stored in DynamoDB successfully!")
    except Exception as e:
        logger.error(f"Error processing data: {e}")
        raise e
